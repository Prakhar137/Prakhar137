/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package randomtask1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;

/**
 *
 * @author Prakhar Dixit
 */
public class RandomTask1 {
    
    List<Long> graph1XValues = new ArrayList<>();
    List<Long> graph1YValues = new ArrayList<>();
    

  // Generate random number
    long[] generateRandomNumber(long lowerLimit, long upperLimit, int numOfValues, boolean noDuplicates) {

        long[] finalList;
        finalList = new long[numOfValues];
        int counter = 0;
        Random r = new Random();

        while (true) {
            long randomNo = r.nextInt((int) (upperLimit - lowerLimit) + 1) + lowerLimit;;

            if (noDuplicates) {
                boolean isAlradyAdded = false;
                for (int i = 0; i < counter; i++) {

                    if (randomNo == finalList[i]) {
                        isAlradyAdded = true;
                        break;
                    }
                }

                if (isAlradyAdded) {
                    continue;
                }
            }

            finalList[counter] = randomNo;

            counter++;
            if (counter >= numOfValues) {
                break;
            }

        }
        // System.out.println("list " + finalList);

        return finalList;
    }

    void printArray(long[] arr) {
        for (int i = 0; i < arr.length; i++) {
            // System.out.print("  " + arr[i]);

        }
    }

    // For save list into file
    void saveToFile(long[] generatedRandomNumber, String filename) {

        PrintWriter writer = null;

        try {
            writer = new PrintWriter(filename, "UTF-8");

            for (int i = 0; i < generatedRandomNumber.length; i++) {
                writer.println(generatedRandomNumber[i]);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(RandomTask1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(RandomTask1.class.getName()).log(Level.SEVERE, null, ex);
        }
        writer.close();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

         RandomTask1 myobject = new RandomTask1();
         myobject.uniqueAndDuplicateRandomValue();
         
        
    }
    
    void uniqueAndDuplicateRandomValue(){
           long lowerLimit = 0;
        long upperLimit = 0;
        int  numberOfValues = 0;
        boolean noDuplicate = true;
        
        
        RandomTask1 myobject = new RandomTask1();

        long milliTestcase1, milliTestcase2;
        
       

        // ******* test case 1 for Unique Random Number ********    
        
        
         myobject.graph1XValues.add((long)0);
        myobject.graph1YValues.add((long)0);

        
        lowerLimit = 10; 
        upperLimit = 800;
        numberOfValues = 200;
        
        String home = System.getProperty("user.home");
        File file = new File(home+"/Downloads/" + "File1" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        long[] list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        long difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 1 for Unique Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 1 total execution time : "
                + difference + " Milliseconds\n");


         // ******* test case 2 for Unique Random Number ********    
        lowerLimit = 20; 
        upperLimit = 3400;
        numberOfValues = 400;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "File2" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list,  file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 2 for Unique Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 2 total execution time : "
                + difference + " Milliseconds\n");
        

         // ******* test case 3 for Unique Random Number ********    
        lowerLimit = 10; 
        upperLimit = 4900;
        numberOfValues = 690;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "File3" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list,  file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 3 for Unique Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 3 total execution time : "
                + difference + " Milliseconds\n");
        
        
         // ******* test case 4 for Unique Random Number ********    
        lowerLimit = 100; 
        upperLimit = 7500;
        numberOfValues = 700;
        
        home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "File4" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 4 for Unique Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 4 total execution time : "
                + difference + " Milliseconds\n");
        
        
         // ******* test case 5 for Unique Random Number ********    
        lowerLimit = 100; 
        upperLimit = 1000;
        numberOfValues = 800;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "File5" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 5 for Unique Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 5 total execution time : "
                + difference + " Milliseconds\n");
        
        
        
        // Duplicate random value data added here.....
        
         myobject.graph1XValues.add((long)0);
        myobject.graph1YValues.add((long)0);
        
        noDuplicate = false;

        
        lowerLimit = 10; 
        upperLimit = 800;
        numberOfValues = 200;
        // System.out.println(""+ noDuplicate);

        
        milliTestcase1 = System.currentTimeMillis();
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 1 for Duplicate Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 1 total execution time : "
                + difference + " Milliseconds\n");
       


         // ******* test case 2 for Duplicate Random Number ********    
        lowerLimit = 20; 
        upperLimit = 3400;
        numberOfValues = 400;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "DuplicateRandomNumberFile2" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list,  file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 2 for Duplicate Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 2 total execution time : "
                + difference + " Milliseconds\n");
        

         // ******* test case 3 for Duplicate Random Number ********    
        lowerLimit = 10; 
        upperLimit = 4900;
        numberOfValues = 690;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "DuplicateRandomNumberFile3" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list,  file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 3 for Duplicate Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 3 total execution time : "
                + difference + " Milliseconds\n");
        
        
         // ******* test case 4 for Duplicate Random Number ********    
        lowerLimit = 100; 
        upperLimit = 7500;
        numberOfValues = 700;
        
        home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "DuplicateRandomNumberFile4" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 4 for Duplicate Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 4 total execution time : "
                + difference + " Milliseconds\n");
        
        
         // ******* test case 5 for Duplicate Random Number ********    
        lowerLimit = 100; 
        upperLimit = 1000;
        numberOfValues = 800;
        
         home = System.getProperty("user.home");
         file = new File(home+"/Downloads/" + "DuplicateRandomNumberFile5" + ".txt");
        
        milliTestcase1 = System.currentTimeMillis();
        list = myobject.generateRandomNumber(lowerLimit, upperLimit, numberOfValues, noDuplicate);
        myobject.saveToFile(list, file + "");
        milliTestcase2 = System.currentTimeMillis();
        difference = (milliTestcase2 - milliTestcase1);
        myobject.graph1XValues.add((long)numberOfValues);
        myobject.graph1YValues.add((long)difference);


        System.out.println("========= Testcase 5 for Duplicate Random Number ==========\n" + "UpperLimit :" + upperLimit + "\n" 
                + "LowerLimit : " + lowerLimit + "\n"
                + "Number of values : " + numberOfValues 
                + "\n" 
                + "TestCase 5 total execution time : "
                + difference + " Milliseconds\n");
        
        myobject.showGraph1();
        
    }
    
    
    
    // Creating graph
    void showGraph1(){
        
        SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            GraphPanel.createAndShowGraph1(graph1XValues,graph1YValues);
         }
      });
    }

}
